#ifndef GPS_H
#define GPS_H

//INCLUDE HEADER FILES
#include "includes.h"

//FUNCTION PROTOTYPE
void GPSInit	(void);
void GPSgetloc	(int8u *Lat, int8u *Lon);

#endif