#ifndef	_TYPES_H
#define _TYPES_H

/* types.h :	user defined data types */
typedef unsigned 	char	int8u;
typedef signed 		char 	int8s;
typedef unsigned 	short 	int16u;
typedef unsigned 	long 	int32u;

#endif

